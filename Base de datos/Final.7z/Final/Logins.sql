-- SQL Server posee dos instancias de seguridad, la primera es el LOGIN el cual nos permite conectarnos
-- a una instancia de SQL Server. Aqui se estan creando esos logins para usuarios
CREATE LOGIN DBA WITH PASSWORD = 'OWL1234'
CREATE LOGIN JAM WITH PASSWORD = 'AnitaLaHuerfanita'
CREATE LOGIN PEANUT WITH PASSWORD = 'butter'

-- La segunda, es la medida de seguridad que nos permite conectarnos a una base de datos dentro de una instancia
-- de SQL Server. La creacion de estos usuarios deben estar basados por los LOGINS disponibles, pero no deben de tener
-- el mismo nombre
CREATE USER DBA FOR LOGIN DBA
CREATE USER JAM FOR LOGIN JAM
CREATE USER PEANUT FOR LOGIN PEANUT

-- Se estan creando dos roles que tendran ciertos permisos limitados dentro de la base de datos
CREATE ROLE marketing
CREATE ROLE cliente

-- Se seleccionan los permisos que tendran cada ROL creado anteriormente
GRANT SELECT ON DIAS_EN_INVENTARIO TO marketing
GRANT SELECT ON MARCAS_MAS_CARAS TO marketing
GRANT SELECT ON MARCAS_MAS_VENDIDAS TO marketing
GRANT SELECT ON MESES_PARA_CONVERTIBLES TO marketing
GRANT SELECT ON TENDENCIAS TO marketing
GRANT SELECT ON VEHICULOS TO cliente
GRANT SELECT ON CONCESIONARIO TO cliente

-- Se altera cada ROL para agregar dentro de ellos los usuarios en los que estamos interesados en disponer de ciertos
-- servicios
ALTER ROLE marketing ADD USER JAM
ALTER ROLE cliente ADD USER PEANUT
-- dbowner es un rol especial que permite modificar la base de datos completamente, posee absolutamente todos los
-- permisos y accesos dentro de la base de datos.
ALTER ROLE dbowner ADD USER DBA