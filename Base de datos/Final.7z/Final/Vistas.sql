 -- PRIMERA VISTA--
 --Determina las tendecias de ventas sobre periodos de tiempo de 3 anios, 1 anio, 1 mes y 1 semana
 --Haciendo distincion entre el rango de sueldos el cual incrementa de 20,000 y el genero del cliente que
 -- hizo la compra
 
CREATE VIEW TENDENCIAS AS(
	(
	SELECT '3YY' AS periodo, Rango_Salario, F, M
	 FROM tendencias_salario_n_genero( (SELECT DATEADD(YEAR, -3, GETDATE())) , 20000)
	)
	UNION
	(
	 SELECT '1YY' AS periodo, Rango_Salario, F, M
	 FROM tendencias_salario_n_genero( (SELECT DATEADD(YEAR, -1, GETDATE())) , 20000)
	)
	UNION
	(
	 SELECT '1MM' AS periodo, Rango_Salario, F, M
	 FROM tendencias_salario_n_genero( (SELECT DATEADD(MONTH, -1, GETDATE())) , 20000 )
	)
	UNION
	(
	 SELECT '1WW' AS periodo, Rango_Salario, F, M
	 FROM tendencias_salario_n_genero( (SELECT DATEADD(WEEK, -1, GETDATE())) , 20000 )
	)
)


-- Segunda Vista --
--- Se debe de extraer con esta vista la informacion de un PROVEEDOR particular entre un rango de fechas
-- CONSULTA SERIA: SELECT * FROM PROVEEDORES_EN_RANGO WHERE Proveedor = 'XXX' AND fechaEntrada BETWEEN '1/12/2024' AND '7/12/2024'
-- Donde el proveedor sera el nombre del proveedor interesado y las fechas serian el rango en que entro el vehiculo al concesionario

CREATE VIEW PROVEEDORES_EN_RANGO AS (
	SELECT PROVEEDORES.nombre AS Proveedor, VEHICULOS.VIN, VENTAS.fecha AS fechaVenta, VEHICULOSXCONCESIONARIOS.adquision AS fechaEntrada
			, CLIENTES.nombre AS Cliente, CLIENTES.noTelefono TelCliente 
	FROM VENTAS JOIN CLIENTES ON VENTAS.idCliente = CLIENTES.idCliente JOIN VEHICULOS ON VENTAS.VIN = VEHICULOS.VIN
		 JOIN MODELOSXPROVEEDORES ON MODELOSXPROVEEDORES.idModelo = VEHICULOS.idModelo
		 JOIN PROVEEDORES ON PROVEEDORES.idProveedor = MODELOSXPROVEEDORES.idProveedor
		 JOIN VEHICULOSXCONCESIONARIOS ON VEHICULOSXCONCESIONARIOS.idConcesionario = VENTAS.idConcesionario AND VEHICULOSXCONCESIONARIOS.VIN = VEHICULOS.VIN
)


--Tercera Vista--
-- Obtiene la las marcas de los vehiculos mas vendidos presentando la suma total en las ventas

CREATE VIEW MARCAS_MAS_CARAS AS 
	WITH R(marca, ventas) AS (SELECT MODELOS.marca, SUM(VENTAS.precio)
						  FROM VEHICULOS JOIN MODELOS ON VEHICULOS.idModelo = MODELOS.idModelo
							JOIN VENTAS ON VEHICULOS.VIN = VENTAS.VIN
							WHERE YEAR(VENTAS.fecha) = YEAR(GETDATE() - 1)
							GROUP BY MODELOS.marca
							), S(marca, ventas, rank_ventas) AS (SELECT R.marca, R.ventas, RANK() OVER (ORDER BY R.ventas DESC) AS rank_ventas FROM R)
	SELECT rank_ventas, marca, ventas
	FROM S
	WHERE S.rank_ventas < 3


-- Cuarta Vista--
-- Presenta las dos marcas mas vendidas por cantidad

CREATE VIEW MARCAS_MAS_VENDIDAS AS 
	WITH R(marca, ventas) AS (SELECT MODELOS.marca, COUNT(*)
						  FROM VEHICULOS JOIN MODELOS ON VEHICULOS.idModelo = MODELOS.idModelo
							JOIN VENTAS ON VEHICULOS.VIN = VENTAS.VIN
							WHERE YEAR(VENTAS.fecha) = YEAR(GETDATE() - 1)
							GROUP BY MODELOS.marca
							), S(marca, ventas, rank_ventas) AS (SELECT R.marca, R.ventas, RANK() OVER (ORDER BY R.ventas DESC) AS rank_ventas FROM R)
	SELECT rank_ventas, marca, ventas
	FROM S
	WHERE S.rank_ventas < 3


--Quinta Vista
-- Regresa las ventas en cada mes de los vehiculos convertibles

CREATE VIEW MESES_PARA_CONVERTIBLES AS
	SELECT DATENAME(MM, VENTAS.fecha) AS mes, COUNT(*) as ventas
	FROM VENTAS JOIN VEHICULOS ON VENTAS.VIN = VEHICULOS.VIN
	JOIN MODELOS ON VEHICULOS.idModelo = MODELOS.idModelo
	WHERE MODELOS.estiloCarroceria = 'CONVERTIBLE'
	GROUP BY MONTH(VENTAS.fecha), DATENAME(MM, VENTAS.fecha);


-- Sexta Vista
-- Retorna una realcion con el promedio en que estan los vehiculos por cada concesionario

CREATE VIEW DIAS_EN_INVENTARIO AS
	WITH S(idConcesionario, VIN, diasxauto) AS (SELECT VENTAS.idConcesionario, VENTAS.VIN, DATEDIFF(DAY, VENTAS.fecha, VEHICULOSXCONCESIONARIOS.adquision) AS diasxauto
						FROM VENTAS JOIN VEHICULOSXCONCESIONARIOS ON VENTAS.VIN = VEHICULOSXCONCESIONARIOS.VIN
						)
	SELECT CONCESIONARIOS.nombre, AVG(S.diasxauto) as PromedioxAuto
	FROM CONCESIONARIOS JOIN S ON CONCESIONARIOS.idConcesionario = S.idConcesionario
	GROUP BY CONCESIONARIOS.nombre
