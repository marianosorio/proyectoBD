--Inserts en ENUM COLOR
INSERT INTO ENUM_COLOR (color) 
VALUES 
('Rojo'), 
('Azul'), 
('Negro'), 
('Blanco'), 
('Gris'), 
('Verde'), 
('Purpura');

--Inserts en ENUM MARCAS
INSERT INTO ENUM_MARCAS (marca)
VALUES 
('Toyota'), 
('Honda'), 
('Ford'), 
('Chevrolet'), 
('Nissan'), 
('Kia'), 
('Hyundai');


--Inserts en ENUM TRANSMISION 
INSERT INTO ENUM_TRANSMISION (transmision) 
VALUES 
('Manual'), 
('Autom�tica');

--Inserts en CLIENTES
INSERT INTO CLIENTES (nombre, direccion, noTelefono, sexo, ingresosAnuales)
VALUES 
('Juan P�rez', 'Boulevard Moraz�n', 12345678, 'M', 25000.00),
('Mar�a L�pez', 'Colonia Palmira', 87654321, 'F', 30000.00),
('Carlos Enrique', 'Avenida La Paz', 23456789, 'M', 15000.00),
('Ana G�mez', 'Colonia El Bosque', 34567890, 'F', 20000.00),
('Luis Mart�nez', 'Calle 10', 98765432, 'M', 28000.00),
('Sof�a Torres', 'Avenida 20', 45678901, 'F', 32000.00),
('Fernando Molina', 'Boulevard 30', 56789012, 'M', 18000.00),
('Claudia Ram�rez', 'Calle 40', 67890123, 'F', 22000.00),
('Javier Morales', 'Colonia 50', 78901234, 'M', 26000.00);

--Inserts en CONSCESIONARIOS
INSERT INTO CONCESIONARIOS(nombre, direccion, noTelefono)
VALUES 
('Excel Auto', 'Colonia Las Mercedes', 12345678),
('AutoPartes', 'Boulevard Centroam�rica', 87654321),
('Carros y M�s', 'Colonia Miraflores', 23456789),
('Repuestos', 'Colonia El Prado', 34567890),
('AutoExcel', 'Colonia La Paz', 45678901);

--Inserts en PLANTAS
INSERT INTO PLANTAS (nombre, ubicacion) 
VALUES 
('Planta 1', 'San Pedro Sula'),
('Planta 2', 'Tegucigalpa');

--Inserts en PROVEEDORES
INSERT INTO PROVEEDORES (nombre, direccion, noTelefono) VALUES 
('Repuestos_Said', 'Boulevard Los Proceres', 45678901),
('AutoPiezas HN', 'Colonia El Prado', 56789012),
('Exel Automotriz ', 'Avenida La Paz', 67890123),
('AutoRespuestos', 'Colonia San Francisco', 78901234),
('AutoPartes Ale', 'Boulevard Moraz�n', 89012345);

--Inserts en MODELOS
INSERT INTO MODELOS (nombre, estiloCarroceria, marca) VALUES 
('Corolla', 'Sed�n', 'Toyota'),
('Civic', 'Sed�n', 'Honda'),
('F-150', 'Pickup', 'Ford'),
('Cruze', 'Sed�n', 'Chevrolet'),
('Versa', 'Sed�n', 'Nissan');

--Insers en VEHICULOS (Ojo se deben de insertar los los ENUM_MARCAS,ENUM_COLOR,MODELOS antes)
INSERT INTO VEHICULOS (VIN, idModelo, color, noMotor, transmision) 
VALUES 
('1HGBH41JXMN109186', 1, 'Rojo', 123456, 'Autom�tica'),
('2HGFG3B51GH123456', 2, 'Azul', 654321, 'Manual'),
('1FTFW1EF1EKE12345', 3, 'Negro', 789012, 'Autom�tica'),
('1G1PC5SH8B1234567', 4, 'Blanco', 345678, 'Manual'),
('3N1AB7APXGL123456', 5, 'Gris', 456789, 'Autom�tica');

--Inserts en VEHICULOSXCONCESIONARIOS --No se por que no me registro el los Inserts en CONCESIONARIOS OMITIO el 1 igual hice 6 para cualquier caso
INSERT INTO VEHICULOSXCONCESIONARIOS (VIN, idConcesionario, adquision) 
VALUES 
('1HGBH41JXMN109186', 2, '2024-01-15'),
('2HGFG3B51GH123456', 4, '2024-01-20'),
('1FTFW1EF1EKE12345', 2, '2024-02-10'),
('1G1PC5SH8B1234567', 3, '2024-02-15'),
('3N1AB7APXGL123456', 5, '2024-03-01');

--Insers en VENTAS
INSERT INTO VENTAS (fecha, idConcesionario, idCliente, VIN, precio)
VALUES 
('2024-01-16', 5, 7, '1HGBH41JXMN109186', 20000.00),
('2024-01-21', 2, 8, '2HGFG3B51GH123456', 22000.00),
('2024-02-11', 2, 9, '1FTFW1EF1EKE12345', 30000.00),
('2024-02-16', 3, 10, '1G1PC5SH8B1234567', 15000.00),
('2024-03-02', 2, 7, '3N1AB7APXGL123456', 18000.00);

--Inserts en MODELOSXPLANTAS
INSERT INTO MODELOSXPLANTAS (idModelo, idPlanta)
VALUES 
(1, 2),  -- Corolla en Planta 1
(2, 1),  -- Civic en Planta 1
(3, 2),  -- F-150 en Planta 2
(4, 2),  -- Cruze en Planta 2
(5, 1);  -- Versa en Planta 1

--Inserts en MODELOSXPROVEEDORES
INSERT INTO MODELOSXPROVEEDORES (idModelo, idProveedor) 
VALUES 
(1, 1),  -- Corolla de Proveedores de Piezas S.A.
(2, 1),  -- Civic de Proveedores de Piezas S.A.
(3, 2),  -- F-150 de Repuestos y Servicios
(4, 3),  -- Honduras Automotriz
(5, 5);  -- Suministros Automotrices
