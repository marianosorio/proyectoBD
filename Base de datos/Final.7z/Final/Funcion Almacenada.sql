-- Funcion Tabla tendecias en salario y genero --
-- Funcin almacenada que retorna una relacion divida en rangos de salarios
-- de los usuarios, dentro de un fecha dada hasta la fecha. Ademas, cada rango de salario
-- esta divido por los generos de los clientes.
-- PARAMETROS
-- datespace date: fecha desde la cual se desea recopilar informacion
-- rangeSalary INT: rangos entre los cuales se deben de dividir los salarios en caso de existir.
CREATE FUNCTION tendencias_salario_n_genero(@datespace date, @rangeSalary INT)
RETURNS TABLE
AS
RETURN (SELECT FLOOR(CLIENTES.ingresosAnuales / @rangeSalary) * @rangeSalary AS Rango_Salario,
		SUM(CASE WHEN CLIENTES.sexo = 'F' THEN 1 ELSE 0 END) AS F,
		SUM(CASE WHEN CLIENTES.sexo = 'M' THEN 1 ELSE 0 END) AS M
	FROM VENTAS JOIN CLIENTES ON VENTAS.idCliente = CLIENTES.idCliente
	WHERE VENTAS.fecha > @datespace
	GROUP BY FLOOR(CLIENTES.ingresosAnuales / @rangeSalary) * @rangeSalary
);
