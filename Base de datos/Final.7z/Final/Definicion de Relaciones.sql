-- Definicion de la relacion PLANTAS --
-- idPlanta: Lllave Primaria con dominio SMALLINT, que permite almacenar 2^16 numero. 
-- IDENTITY es el comando para autoincremento donde el primer parametro indica el comienzo
-- del incremento y el segundo en cuando debe de incrementar por cada entrada
CREATE TABLE PLANTAS(
	idPlanta SMALLINT IDENTITY(1,1) PRIMARY KEY,
	nombre VARCHAR(15) NOT NULL,
	ubicacion VARCHAR(25) NOT NULL
)

-- Definicion de la relacion PROVEEDORES --
-- idProveedore: Llave primario de dominio INT, nos permite almacenar 2^32 numeros. INDENTITY es el comando para autoincrementar
CREATE TABLE PROVEEDORES(
	idProveedor INT IDENTITY(1,1) PRIMARY KEY,
	nombre VARCHAR(15) NOT NULL,
	direccion VARCHAR(25) NOT NULL,
	noTelefono int NOT NULL
)

-- Definicion relacion auxiliar ENUM_MARCAS --
-- Debido a que SQL Server no soporta el tipo de dato enumerado, se crea una relacion auxiliar que hara el rol
-- de un lista para la relacion MODELOS
CREATE TABLE ENUM_MARCAS(
	marca VARCHAR(15) PRIMARY KEY
)

-- Definicion de la relacion MODELOS -- 
-- idModelo: Llave Primaria con domio INT, permite almacenar hasta 2^32 digitos. IDENTITY indicando que es autoincremental
-- marca: Atributo que hace referencia a la relacion auxiliar ENUM_MARCAS, esto para emular un tipo enumerado
CREATE TABLE MODELOS(
	idModelo INT IDENTITY(1,1) PRIMARY KEY,
	nombre VARCHAR(15) NOT NULL,
	estiloCarroceria VARCHAR(15) NOT NULL,
	marca VARCHAR(15) NOT NULL,
	FOREIGN KEY (marca) REFERENCES ENUM_MARCAS(marca) ON UPDATE CASCADE
)

-- Definicion de relacion MODELOSXPLANTAS --
-- Relacion transaccional donde idModelo es una llave forenea que referencia a la relacion MODELOS y
-- idPlanta referencia a la relacion PLANTAS. Ambos atributos conforman la llave primaria
CREATE TABLE MODELOSXPLANTAS(
	idModelo INT,
	idPlanta SMALLINT,
	PRIMARY KEY (idModelo, idPlanta),
	FOREIGN KEY (idModelo) REFERENCES MODELOS(idModelo) ON UPDATE CASCADE,
	FOREIGN KEY (idPlanta) REFERENCES PLANTAS(idPlanta) ON UPDATE CASCADE
)

-- Definicion de relacion MODELOSXPROVEEDORES --
-- Relacion transaccional donde idModelo es una llave forenea que referencia a la relacion MODELOS y
-- idProveedor referencia a la relacion PROVEEDORES. Ambos atributos conforman la llave primaria
CREATE TABLE MODELOSXPROVEEDORES(
	idModelo INT,
	idProveedor INT,
	PRIMARY KEY(idModelo, idProveedor),
	FOREIGN KEY (idModelo) REFERENCES MODELOS(idModelo) ON UPDATE CASCADE,
	FOREIGN KEY (idProveedor) REFERENCES PROVEEDORES(idProveedor) ON UPDATE CASCADE
)

-- Definicion relacion auxiliar ENUM_COLOR --
-- Debido a que SQL Server no soporta el tipo de dato enumerado, se crea una relacion auxiliar que hara el rol
-- de un lista para la relacion VEHICULOS, en el atributo color
CREATE TABLE ENUM_COLOR(
	color VARCHAR(15) PRIMARY KEY
)

-- Definicion relacion auxiliar ENUM_TRANSMISION --
-- Debido a que SQL Server no soporta el tipo de dato enumerado, se crea una relacion auxiliar que hara el rol
-- de un lista para la relacion VEHICULOS, en el atributo transmision
CREATE TABLE ENUM_TRANSMISION(
	transmision VARCHAR(15) PRIMARY KEY
)

-- Definicion de  relacion VEHICULOS --
-- VIN: Llave Primaria del tipo VARCHAR con 17 valores alfanumericos como limite
-- color: Atributo que hace referencia a la relacion auxiliar ENUM_COLOR, esto para emular un tipo enumerado
-- transmision: Atributo que hace referencia a la relacion auxiliar ENUM_TRANSMISION, esto para emular un tipo enumerado
CREATE TABLE VEHICULOS(
	VIN VARCHAR(17) PRIMARY KEY,
	idModelo INT NOT NULL,
	color VARCHAR(15) NOT NULL,
	noMotor int NOT NULL,
	transmision VARCHAR(15) NOT NULL,
	FOREIGN KEY (idModelo) REFERENCES MODELOS(idModelo) ON UPDATE CASCADE,
	FOREIGN KEY (color) REFERENCES ENUM_COLOR(color) ON UPDATE CASCADE,
	FOREIGN KEY (transmision) REFERENCES ENUM_TRANSMISION(transmision) ON UPDATE CASCADE
)

-- Definicion de realacion CONCESIONARIOS --
-- idConcesionario: Llave primaria con dominio SMALLINT que nos permite almacenar hasta 2^16 numeros. IDENTITY genera los valores autoincrementales
CREATE TABLE CONCESIONARIOS(
	idConcesionario SMALLINT IDENTITY(1,1) PRIMARY KEY,
	nombre VARCHAR(15) NOT NULL,
	direccion VARCHAR (25) NOT NULL,
	noTelefono INT NOT NULL,
)

-- Definicion de relacion VEHICULOSXCONCESIONARIOS --
-- Relacion transaccional donde VIN es una llave forenea que referencia a la relacion VEHICULOS y
-- idConcesionario referencia a la relacion PROVEEDORES. Ambos atributos conforman la llave primaria
-- adquision: representa la fecha en que un vehiculo fue adquirido por cierto concesionario
CREATE TABLE VEHICULOSXCONCESIONARIOS(
	VIN VARCHAR(17),
	idConcesionario SMALLINT,
	adquision DATE NOT NULL,
	PRIMARY KEY(VIN, idConcesionario),
	FOREIGN KEY (VIN) REFERENCES VEHICULOS(VIN) ON UPDATE CASCADE,
	FOREIGN KEY (idConcesionario) REFERENCES CONCESIONARIOS(idConcesionario) ON UPDATE CASCADE
)

-- Definicion de relacion CLIENTES --
-- idClientes: Llave primaria con dominio INT, permite almacenar hasta 2^32 numeros. IDENTITY generara numeros de manera incremental automatica
-- sexo: se implementa un CHECK que limita el genero de una persona a F como Femenino y M como Masculino
-- ingresosAnuelos: implementa un CHECK que limita el ingreso a valores positivos unicamente. Con 10 digitos como maximo, y 2 de eso como decimal
CREATE TABLE CLIENTES(
	idCliente INT IDENTITY(1,1) PRIMARY KEY,
	nombre VARCHAR(15) NOT NULL,
	direccion VARCHAR(25) NOT NULL,
	noTelefono INT NOT NULL,
	sexo VARCHAR(1) CHECK ( sexo in ('F', 'M')),
	ingresosAnuales DECIMAL(10,2) CHECK(ingresosAnuales > 0)
)

-- Definicion de relacion VENTAS --
-- idVenta: llave primaria con domicio INT, permite almacenar hasta 2^32 numeros. IDENTITY generara valor autoincremental
-- idConcesionario: llave foranea que hace referencia a la relacion CONCESIONARIOS
-- idCliente: Llave foranea que hace referencia a la relacion CLIENTES
-- VIN: Llave foranea que hace referencia a la relacion VEHICULOS
-- precio: valor por el cual se vendio un vehiculo el cual esta limitado por valores mayores a 0 y con hasta 9 digitos, 2 de ellos pudiendo ser decimales
CREATE TABLE VENTAS(
	idVenta INT IDENTITY(1,1) PRIMARY KEY,
	fecha DATE NOT NULL,
	idConcesionario SMALLINT NOT NULL,
	idCliente INT NOT NULL,
	VIN VARCHAR(17) NOT NULL,
	precio DECIMAL(9,2) NOT NULL CHECK (precio > 0),
	FOREIGN KEY (idConcesionario) REFERENCES Concesionarios(idConcesionario) ON UPDATE CASCADE,
	FOREIGN KEY (idCliente) REFERENCES CLIENTES(idCliente) ON UPDATE CASCADE
)

-- Definicion de relacion BITACORA --
-- Relacion aislada que lleva control de las modificaciones en los estados de la base en las relaciones principales
-- fuertes
-- idBitacora: Llave primaria con dominio BIGINT, el cual nos permite almacenar 2^64 numeros. IDENTITY genera autoincrementos
-- accion: describe la accion tomada por un usuario, limitando a registrar solo UPDATE, DELETE e INSERT
CREATE TABLE BITACORA(
	idBitacora BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	accion VARCHAR(10) NOT NULL CHECK( accion IN ('DELETE', 'UPDATE', 'INSERT')),
	relacion VARCHAR(50) NOT NULL,
	fecha DATETIME2(7) NULL,
	idUsuario INT NOT NULL,
	nombreUsuario VARCHAR(50) NOT NULL,
)